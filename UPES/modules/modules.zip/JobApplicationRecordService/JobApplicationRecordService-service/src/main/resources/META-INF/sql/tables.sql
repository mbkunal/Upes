create table KMB_Job_Application_Records (
	SapId LONG not null,
	JobId LONG not null,
	ApplicationDate DATE null,
	primary key (SapId, JobId)
);

create table KMB_fetchLatest (
	isLatest BOOLEAN not null primary key,
	recordNumber LONG
);