/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package JobApplicationRecordService.service;

import aQute.bnd.annotation.ProviderType;

import com.liferay.osgi.util.ServiceTrackerFactory;

import org.osgi.util.tracker.ServiceTracker;

/**
 * Provides the local service utility for fetchLatest. This utility wraps
 * {@link JobApplicationRecordService.service.impl.fetchLatestLocalServiceImpl} and is the
 * primary access point for service operations in application layer code running
 * on the local server. Methods of this service will not have security checks
 * based on the propagated JAAS credentials because this service can only be
 * accessed from within the same VM.
 *
 * @author Brian Wing Shun Chan
 * @see fetchLatestLocalService
 * @see JobApplicationRecordService.service.base.fetchLatestLocalServiceBaseImpl
 * @see JobApplicationRecordService.service.impl.fetchLatestLocalServiceImpl
 * @generated
 */
@ProviderType
public class fetchLatestLocalServiceUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Add custom service methods to {@link JobApplicationRecordService.service.impl.fetchLatestLocalServiceImpl} and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	* Adds the fetch latest to the database. Also notifies the appropriate model listeners.
	*
	* @param fetchLatest the fetch latest
	* @return the fetch latest that was added
	*/
	public static JobApplicationRecordService.model.fetchLatest addfetchLatest(
		JobApplicationRecordService.model.fetchLatest fetchLatest) {
		return getService().addfetchLatest(fetchLatest);
	}

	/**
	* Creates a new fetch latest with the primary key. Does not add the fetch latest to the database.
	*
	* @param isLatest the primary key for the new fetch latest
	* @return the new fetch latest
	*/
	public static JobApplicationRecordService.model.fetchLatest createfetchLatest(
		boolean isLatest) {
		return getService().createfetchLatest(isLatest);
	}

	/**
	* Deletes the fetch latest from the database. Also notifies the appropriate model listeners.
	*
	* @param fetchLatest the fetch latest
	* @return the fetch latest that was removed
	*/
	public static JobApplicationRecordService.model.fetchLatest deletefetchLatest(
		JobApplicationRecordService.model.fetchLatest fetchLatest) {
		return getService().deletefetchLatest(fetchLatest);
	}

	/**
	* Deletes the fetch latest with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param isLatest the primary key of the fetch latest
	* @return the fetch latest that was removed
	* @throws PortalException if a fetch latest with the primary key could not be found
	*/
	public static JobApplicationRecordService.model.fetchLatest deletefetchLatest(
		boolean isLatest)
		throws com.liferay.portal.kernel.exception.PortalException {
		return getService().deletefetchLatest(isLatest);
	}

	public static JobApplicationRecordService.model.fetchLatest fetchfetchLatest(
		boolean isLatest) {
		return getService().fetchfetchLatest(isLatest);
	}

	/**
	* Returns the fetch latest with the primary key.
	*
	* @param isLatest the primary key of the fetch latest
	* @return the fetch latest
	* @throws PortalException if a fetch latest with the primary key could not be found
	*/
	public static JobApplicationRecordService.model.fetchLatest getfetchLatest(
		boolean isLatest)
		throws com.liferay.portal.kernel.exception.PortalException {
		return getService().getfetchLatest(isLatest);
	}

	/**
	* Updates the fetch latest in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param fetchLatest the fetch latest
	* @return the fetch latest that was updated
	*/
	public static JobApplicationRecordService.model.fetchLatest updatefetchLatest(
		JobApplicationRecordService.model.fetchLatest fetchLatest) {
		return getService().updatefetchLatest(fetchLatest);
	}

	public static com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery getActionableDynamicQuery() {
		return getService().getActionableDynamicQuery();
	}

	public static com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return getService().dynamicQuery();
	}

	public static com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery getIndexableActionableDynamicQuery() {
		return getService().getIndexableActionableDynamicQuery();
	}

	/**
	* @throws PortalException
	*/
	public static com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
		com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {
		return getService().deletePersistedModel(persistedModel);
	}

	public static com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {
		return getService().getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns the number of fetch latests.
	*
	* @return the number of fetch latests
	*/
	public static int getfetchLatestsCount() {
		return getService().getfetchLatestsCount();
	}

	/**
	* Returns the OSGi service identifier.
	*
	* @return the OSGi service identifier
	*/
	public static java.lang.String getOSGiServiceIdentifier() {
		return getService().getOSGiServiceIdentifier();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	*/
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {
		return getService().dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link JobApplicationRecordService.model.impl.fetchLatestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	*/
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {
		return getService().dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link JobApplicationRecordService.model.impl.fetchLatestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	*/
	public static <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {
		return getService()
				   .dynamicQuery(dynamicQuery, start, end, orderByComparator);
	}

	/**
	* Returns a range of all the fetch latests.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link JobApplicationRecordService.model.impl.fetchLatestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of fetch latests
	* @param end the upper bound of the range of fetch latests (not inclusive)
	* @return the range of fetch latests
	*/
	public static java.util.List<JobApplicationRecordService.model.fetchLatest> getfetchLatests(
		int start, int end) {
		return getService().getfetchLatests(start, end);
	}

	/**
	* Returns the number of rows matching the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows matching the dynamic query
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {
		return getService().dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows matching the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows matching the dynamic query
	*/
	public static long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {
		return getService().dynamicQueryCount(dynamicQuery, projection);
	}

	public static fetchLatestLocalService getService() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker<fetchLatestLocalService, fetchLatestLocalService> _serviceTracker =
		ServiceTrackerFactory.open(fetchLatestLocalService.class);
}