/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package JobApplicationRecordService.service;

import aQute.bnd.annotation.ProviderType;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link fetchLatestLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see fetchLatestLocalService
 * @generated
 */
@ProviderType
public class fetchLatestLocalServiceWrapper implements fetchLatestLocalService,
	ServiceWrapper<fetchLatestLocalService> {
	public fetchLatestLocalServiceWrapper(
		fetchLatestLocalService fetchLatestLocalService) {
		_fetchLatestLocalService = fetchLatestLocalService;
	}

	/**
	* Adds the fetch latest to the database. Also notifies the appropriate model listeners.
	*
	* @param fetchLatest the fetch latest
	* @return the fetch latest that was added
	*/
	@Override
	public JobApplicationRecordService.model.fetchLatest addfetchLatest(
		JobApplicationRecordService.model.fetchLatest fetchLatest) {
		return _fetchLatestLocalService.addfetchLatest(fetchLatest);
	}

	/**
	* Creates a new fetch latest with the primary key. Does not add the fetch latest to the database.
	*
	* @param isLatest the primary key for the new fetch latest
	* @return the new fetch latest
	*/
	@Override
	public JobApplicationRecordService.model.fetchLatest createfetchLatest(
		boolean isLatest) {
		return _fetchLatestLocalService.createfetchLatest(isLatest);
	}

	/**
	* Deletes the fetch latest from the database. Also notifies the appropriate model listeners.
	*
	* @param fetchLatest the fetch latest
	* @return the fetch latest that was removed
	*/
	@Override
	public JobApplicationRecordService.model.fetchLatest deletefetchLatest(
		JobApplicationRecordService.model.fetchLatest fetchLatest) {
		return _fetchLatestLocalService.deletefetchLatest(fetchLatest);
	}

	/**
	* Deletes the fetch latest with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param isLatest the primary key of the fetch latest
	* @return the fetch latest that was removed
	* @throws PortalException if a fetch latest with the primary key could not be found
	*/
	@Override
	public JobApplicationRecordService.model.fetchLatest deletefetchLatest(
		boolean isLatest)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _fetchLatestLocalService.deletefetchLatest(isLatest);
	}

	@Override
	public JobApplicationRecordService.model.fetchLatest fetchfetchLatest(
		boolean isLatest) {
		return _fetchLatestLocalService.fetchfetchLatest(isLatest);
	}

	/**
	* Returns the fetch latest with the primary key.
	*
	* @param isLatest the primary key of the fetch latest
	* @return the fetch latest
	* @throws PortalException if a fetch latest with the primary key could not be found
	*/
	@Override
	public JobApplicationRecordService.model.fetchLatest getfetchLatest(
		boolean isLatest)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _fetchLatestLocalService.getfetchLatest(isLatest);
	}

	/**
	* Updates the fetch latest in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param fetchLatest the fetch latest
	* @return the fetch latest that was updated
	*/
	@Override
	public JobApplicationRecordService.model.fetchLatest updatefetchLatest(
		JobApplicationRecordService.model.fetchLatest fetchLatest) {
		return _fetchLatestLocalService.updatefetchLatest(fetchLatest);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery getActionableDynamicQuery() {
		return _fetchLatestLocalService.getActionableDynamicQuery();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _fetchLatestLocalService.dynamicQuery();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery getIndexableActionableDynamicQuery() {
		return _fetchLatestLocalService.getIndexableActionableDynamicQuery();
	}

	/**
	* @throws PortalException
	*/
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
		com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _fetchLatestLocalService.deletePersistedModel(persistedModel);
	}

	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _fetchLatestLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Returns the number of fetch latests.
	*
	* @return the number of fetch latests
	*/
	@Override
	public int getfetchLatestsCount() {
		return _fetchLatestLocalService.getfetchLatestsCount();
	}

	/**
	* Returns the OSGi service identifier.
	*
	* @return the OSGi service identifier
	*/
	@Override
	public java.lang.String getOSGiServiceIdentifier() {
		return _fetchLatestLocalService.getOSGiServiceIdentifier();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	*/
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {
		return _fetchLatestLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link JobApplicationRecordService.model.impl.fetchLatestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	*/
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {
		return _fetchLatestLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link JobApplicationRecordService.model.impl.fetchLatestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	*/
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {
		return _fetchLatestLocalService.dynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	* Returns a range of all the fetch latests.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link JobApplicationRecordService.model.impl.fetchLatestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of fetch latests
	* @param end the upper bound of the range of fetch latests (not inclusive)
	* @return the range of fetch latests
	*/
	@Override
	public java.util.List<JobApplicationRecordService.model.fetchLatest> getfetchLatests(
		int start, int end) {
		return _fetchLatestLocalService.getfetchLatests(start, end);
	}

	/**
	* Returns the number of rows matching the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows matching the dynamic query
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {
		return _fetchLatestLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows matching the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows matching the dynamic query
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {
		return _fetchLatestLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public fetchLatestLocalService getWrappedService() {
		return _fetchLatestLocalService;
	}

	@Override
	public void setWrappedService(
		fetchLatestLocalService fetchLatestLocalService) {
		_fetchLatestLocalService = fetchLatestLocalService;
	}

	private fetchLatestLocalService _fetchLatestLocalService;
}