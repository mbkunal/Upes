drop database if exists lportal;
create database lportal character set utf8;
use lportal;



create index IX_91C09A71 on kmb_customFieldAggregationTable (SapId);


