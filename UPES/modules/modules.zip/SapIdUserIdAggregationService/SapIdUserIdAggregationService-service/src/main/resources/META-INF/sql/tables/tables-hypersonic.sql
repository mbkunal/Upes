create table kmb_customFieldAggregationTable (
	UserId int,
	SapId int not null primary key,
	Cgpa double
);
