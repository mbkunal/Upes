create table kmb_customFieldAggregationTable (
	UserId INTEGER,
	SapId INTEGER not null primary key,
	Cgpa DOUBLE
);