create table kmb_customFieldAggregationTable (
	UserId integer,
	SapId integer not null primary key,
	Cgpa double
) engine InnoDB;
