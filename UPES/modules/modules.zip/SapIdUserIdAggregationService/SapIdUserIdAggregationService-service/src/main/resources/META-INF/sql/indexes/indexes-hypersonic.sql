create index IX_91C09A71 on kmb_customFieldAggregationTable (SapId);
