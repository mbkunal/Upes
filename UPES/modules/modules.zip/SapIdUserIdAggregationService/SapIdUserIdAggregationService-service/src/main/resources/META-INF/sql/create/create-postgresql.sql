drop database lportal;
create database lportal encoding = 'UNICODE';
\c lportal;



create index IX_91C09A71 on kmb_customFieldAggregationTable (SapId);


