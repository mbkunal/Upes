package CustomFieldTableAggregator.constants;

/**
 * @author K.M.B
 */
public class AggregatorPortletKeys {

	public static final String Aggregator = "Aggregator";

}