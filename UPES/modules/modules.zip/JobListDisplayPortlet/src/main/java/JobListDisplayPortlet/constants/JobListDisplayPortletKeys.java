package JobListDisplayPortlet.constants;

/**
 * @author K.M.B
 */
public class JobListDisplayPortletKeys {

	public static final String JobListDisplay = "JobListDisplay";

}