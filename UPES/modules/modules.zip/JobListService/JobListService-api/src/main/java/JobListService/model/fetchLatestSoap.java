/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package JobListService.model;

import aQute.bnd.annotation.ProviderType;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link JobListService.service.http.fetchLatestServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @see JobListService.service.http.fetchLatestServiceSoap
 * @generated
 */
@ProviderType
public class fetchLatestSoap implements Serializable {
	public static fetchLatestSoap toSoapModel(fetchLatest model) {
		fetchLatestSoap soapModel = new fetchLatestSoap();

		soapModel.setIsLatest(model.getIsLatest());
		soapModel.setRecordNumber(model.getRecordNumber());

		return soapModel;
	}

	public static fetchLatestSoap[] toSoapModels(fetchLatest[] models) {
		fetchLatestSoap[] soapModels = new fetchLatestSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static fetchLatestSoap[][] toSoapModels(fetchLatest[][] models) {
		fetchLatestSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new fetchLatestSoap[models.length][models[0].length];
		}
		else {
			soapModels = new fetchLatestSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static fetchLatestSoap[] toSoapModels(List<fetchLatest> models) {
		List<fetchLatestSoap> soapModels = new ArrayList<fetchLatestSoap>(models.size());

		for (fetchLatest model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new fetchLatestSoap[soapModels.size()]);
	}

	public fetchLatestSoap() {
	}

	public boolean getPrimaryKey() {
		return _isLatest;
	}

	public void setPrimaryKey(boolean pk) {
		setIsLatest(pk);
	}

	public boolean getIsLatest() {
		return _isLatest;
	}

	public boolean isIsLatest() {
		return _isLatest;
	}

	public void setIsLatest(boolean isLatest) {
		_isLatest = isLatest;
	}

	public long getRecordNumber() {
		return _recordNumber;
	}

	public void setRecordNumber(long recordNumber) {
		_recordNumber = recordNumber;
	}

	private boolean _isLatest;
	private long _recordNumber;
}