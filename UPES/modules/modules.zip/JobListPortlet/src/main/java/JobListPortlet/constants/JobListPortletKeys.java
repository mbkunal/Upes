package JobListPortlet.constants;

/**
 * @author K.M.B
 */
public class JobListPortletKeys {

	public static final String JobList = "JobList";

}