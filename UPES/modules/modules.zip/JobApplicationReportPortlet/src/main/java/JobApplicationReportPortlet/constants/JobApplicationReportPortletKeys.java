package JobApplicationReportPortlet.constants;

/**
 * @author K.M.B
 */
public class JobApplicationReportPortletKeys {

	public static final String JobApplicationReport = "JobApplicationReport";

}