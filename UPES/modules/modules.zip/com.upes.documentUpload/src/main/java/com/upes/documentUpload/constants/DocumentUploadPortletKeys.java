package com.upes.documentUpload.constants;

/**
 * @author K.M.B
 */
public class DocumentUploadPortletKeys {

	public static final String DocumentUpload = "DocumentUpload";
	public static final String uploadParameterName = "docUpload";
	public static final String docsFolder = "MyDocs";

}