package com.upes.documentUpload.portlet;

import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;

import org.osgi.service.component.annotations.Component;

import com.liferay.document.library.kernel.model.DLFileEntry;
import com.liferay.document.library.kernel.model.DLFolder;
import com.liferay.document.library.kernel.model.DLFolderConstants;
import com.liferay.document.library.kernel.service.DLAppLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.repository.model.Folder;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.ServiceContextFactory;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.MimeTypesUtil;
import com.liferay.portal.kernel.util.PortalUtil;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.upes.documentUpload.constants.DocumentUploadPortletKeys;

/**
 * @author K.M.B
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Upload Document",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + DocumentUploadPortletKeys.DocumentUpload,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class DocumentUploadPortlet extends MVCPortlet {
	
	
	
	public void uploadDocs(ActionRequest actionRequest, ActionResponse actionResponse){
		UploadPortletRequest uploadPortletRequest = PortalUtil.getUploadPortletRequest(actionRequest);
		String fileName = uploadPortletRequest.getFileName(DocumentUploadPortletKeys.uploadParameterName);
		InputStream inputStream =null;
		String mimeType = null;
		String title = StringPool.BLANK;
		ServiceContext serviceContext = null;
		try {
			inputStream = uploadPortletRequest.getFileAsStream(DocumentUploadPortletKeys.uploadParameterName);
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(Validator.isNotNull(inputStream) ){
			ThemeDisplay themeDisplay = (ThemeDisplay) actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
			Folder bulkUploadFolder = createFolder(actionRequest, themeDisplay, DLFolderConstants.DEFAULT_PARENT_FOLDER_ID, DocumentUploadPortletKeys.docsFolder);
			mimeType = MimeTypesUtil.getContentType(fileName);
			title = themeDisplay.getUserId()+"_"+(new Date().getTime());
			try {
				serviceContext = ServiceContextFactory.getInstance(DLFileEntry.class.getName(), actionRequest);
				DLAppLocalServiceUtil.addFileEntry(themeDisplay.getUserId(), themeDisplay.getScopeGroupId(),
						bulkUploadFolder.getFolderId(), fileName, mimeType, title, StringPool.BLANK, StringPool.BLANK,
						inputStream, 0, serviceContext);
			} catch (PortalException e) {
				e.printStackTrace();
			}
			
			
		}
		
		
		
		
		
		
	}

	private Folder createFolder(ActionRequest actionRequest, ThemeDisplay themeDisplay, long parentFolderId,
			String folderName) {
	
		Folder folder = getFolder(themeDisplay, parentFolderId, folderName);
		if(Validator.isNull(folder)){
			try{
				ServiceContext serviceContext = ServiceContextFactory.getInstance(DLFolder.class.getName(),	actionRequest);
				folder = DLAppLocalServiceUtil.addFolder(themeDisplay.getUserId(), themeDisplay.getScopeGroupId(), parentFolderId, folderName, "", serviceContext);
			}
			catch (Exception e) {
				e.printStackTrace();
			}			
		}
		return folder;	
	}
	public static Folder getFolder(ThemeDisplay themeDisplay, long parentFolderId, String folderName) {
		Folder folder = null;
		try {
			folder = DLAppLocalServiceUtil.getFolder(themeDisplay.getScopeGroupId(), parentFolderId, folderName);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return folder;
	}
}