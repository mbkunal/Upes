/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package JobApplicationRecordService2.model;

import aQute.bnd.annotation.ProviderType;

import com.liferay.expando.kernel.model.ExpandoBridge;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.service.ServiceContext;

import java.io.Serializable;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * This class is a wrapper for {@link fetchLatest}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see fetchLatest
 * @generated
 */
@ProviderType
public class fetchLatestWrapper implements fetchLatest,
	ModelWrapper<fetchLatest> {
	public fetchLatestWrapper(fetchLatest fetchLatest) {
		_fetchLatest = fetchLatest;
	}

	@Override
	public Class<?> getModelClass() {
		return fetchLatest.class;
	}

	@Override
	public String getModelClassName() {
		return fetchLatest.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("isLatest", getIsLatest());
		attributes.put("recordNumber", getRecordNumber());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Boolean isLatest = (Boolean)attributes.get("isLatest");

		if (isLatest != null) {
			setIsLatest(isLatest);
		}

		Long recordNumber = (Long)attributes.get("recordNumber");

		if (recordNumber != null) {
			setRecordNumber(recordNumber);
		}
	}

	@Override
	public JobApplicationRecordService2.model.fetchLatest toEscapedModel() {
		return new fetchLatestWrapper(_fetchLatest.toEscapedModel());
	}

	@Override
	public JobApplicationRecordService2.model.fetchLatest toUnescapedModel() {
		return new fetchLatestWrapper(_fetchLatest.toUnescapedModel());
	}

	/**
	* Returns the is latest of this fetch latest.
	*
	* @return the is latest of this fetch latest
	*/
	@Override
	public boolean getIsLatest() {
		return _fetchLatest.getIsLatest();
	}

	/**
	* Returns the primary key of this fetch latest.
	*
	* @return the primary key of this fetch latest
	*/
	@Override
	public boolean getPrimaryKey() {
		return _fetchLatest.getPrimaryKey();
	}

	@Override
	public boolean isCachedModel() {
		return _fetchLatest.isCachedModel();
	}

	@Override
	public boolean isEscapedModel() {
		return _fetchLatest.isEscapedModel();
	}

	/**
	* Returns <code>true</code> if this fetch latest is is latest.
	*
	* @return <code>true</code> if this fetch latest is is latest; <code>false</code> otherwise
	*/
	@Override
	public boolean isIsLatest() {
		return _fetchLatest.isIsLatest();
	}

	@Override
	public boolean isNew() {
		return _fetchLatest.isNew();
	}

	@Override
	public ExpandoBridge getExpandoBridge() {
		return _fetchLatest.getExpandoBridge();
	}

	@Override
	public com.liferay.portal.kernel.model.CacheModel<JobApplicationRecordService2.model.fetchLatest> toCacheModel() {
		return _fetchLatest.toCacheModel();
	}

	@Override
	public int compareTo(
		JobApplicationRecordService2.model.fetchLatest fetchLatest) {
		return _fetchLatest.compareTo(fetchLatest);
	}

	@Override
	public int hashCode() {
		return _fetchLatest.hashCode();
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _fetchLatest.getPrimaryKeyObj();
	}

	@Override
	public java.lang.Object clone() {
		return new fetchLatestWrapper((fetchLatest)_fetchLatest.clone());
	}

	@Override
	public java.lang.String toString() {
		return _fetchLatest.toString();
	}

	@Override
	public java.lang.String toXmlString() {
		return _fetchLatest.toXmlString();
	}

	/**
	* Returns the record number of this fetch latest.
	*
	* @return the record number of this fetch latest
	*/
	@Override
	public long getRecordNumber() {
		return _fetchLatest.getRecordNumber();
	}

	@Override
	public void persist() {
		_fetchLatest.persist();
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_fetchLatest.setCachedModel(cachedModel);
	}

	@Override
	public void setExpandoBridgeAttributes(ExpandoBridge expandoBridge) {
		_fetchLatest.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.kernel.model.BaseModel<?> baseModel) {
		_fetchLatest.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(ServiceContext serviceContext) {
		_fetchLatest.setExpandoBridgeAttributes(serviceContext);
	}

	/**
	* Sets whether this fetch latest is is latest.
	*
	* @param isLatest the is latest of this fetch latest
	*/
	@Override
	public void setIsLatest(boolean isLatest) {
		_fetchLatest.setIsLatest(isLatest);
	}

	@Override
	public void setNew(boolean n) {
		_fetchLatest.setNew(n);
	}

	/**
	* Sets the primary key of this fetch latest.
	*
	* @param primaryKey the primary key of this fetch latest
	*/
	@Override
	public void setPrimaryKey(boolean primaryKey) {
		_fetchLatest.setPrimaryKey(primaryKey);
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		_fetchLatest.setPrimaryKeyObj(primaryKeyObj);
	}

	/**
	* Sets the record number of this fetch latest.
	*
	* @param recordNumber the record number of this fetch latest
	*/
	@Override
	public void setRecordNumber(long recordNumber) {
		_fetchLatest.setRecordNumber(recordNumber);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof fetchLatestWrapper)) {
			return false;
		}

		fetchLatestWrapper fetchLatestWrapper = (fetchLatestWrapper)obj;

		if (Objects.equals(_fetchLatest, fetchLatestWrapper._fetchLatest)) {
			return true;
		}

		return false;
	}

	@Override
	public fetchLatest getWrappedModel() {
		return _fetchLatest;
	}

	@Override
	public boolean isEntityCacheEnabled() {
		return _fetchLatest.isEntityCacheEnabled();
	}

	@Override
	public boolean isFinderCacheEnabled() {
		return _fetchLatest.isFinderCacheEnabled();
	}

	@Override
	public void resetOriginalValues() {
		_fetchLatest.resetOriginalValues();
	}

	private final fetchLatest _fetchLatest;
}