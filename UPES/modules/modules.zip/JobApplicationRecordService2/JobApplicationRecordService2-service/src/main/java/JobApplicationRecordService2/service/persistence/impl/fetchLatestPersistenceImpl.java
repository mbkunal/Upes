/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package JobApplicationRecordService2.service.persistence.impl;

import JobApplicationRecordService2.exception.NoSuchfetchLatestException;

import JobApplicationRecordService2.model.fetchLatest;

import JobApplicationRecordService2.model.impl.fetchLatestImpl;
import JobApplicationRecordService2.model.impl.fetchLatestModelImpl;

import JobApplicationRecordService2.service.persistence.fetchLatestPersistence;

import aQute.bnd.annotation.ProviderType;

import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.StringBundler;
import com.liferay.portal.kernel.util.StringPool;
import com.liferay.portal.spring.extender.service.ServiceReference;

import java.io.Serializable;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The persistence implementation for the fetch latest service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see fetchLatestPersistence
 * @see JobApplicationRecordService2.service.persistence.fetchLatestUtil
 * @generated
 */
@ProviderType
public class fetchLatestPersistenceImpl extends BasePersistenceImpl<fetchLatest>
	implements fetchLatestPersistence {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use {@link fetchLatestUtil} to access the fetch latest persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY = fetchLatestImpl.class.getName();
	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List1";
	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION = FINDER_CLASS_NAME_ENTITY +
		".List2";
	public static final FinderPath FINDER_PATH_WITH_PAGINATION_FIND_ALL = new FinderPath(fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
			fetchLatestModelImpl.FINDER_CACHE_ENABLED, fetchLatestImpl.class,
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL = new FinderPath(fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
			fetchLatestModelImpl.FINDER_CACHE_ENABLED, fetchLatestImpl.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0]);
	public static final FinderPath FINDER_PATH_COUNT_ALL = new FinderPath(fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
			fetchLatestModelImpl.FINDER_CACHE_ENABLED, Long.class,
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll", new String[0]);

	public fetchLatestPersistenceImpl() {
		setModelClass(fetchLatest.class);
	}

	/**
	 * Caches the fetch latest in the entity cache if it is enabled.
	 *
	 * @param fetchLatest the fetch latest
	 */
	@Override
	public void cacheResult(fetchLatest fetchLatest) {
		entityCache.putResult(fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
			fetchLatestImpl.class, fetchLatest.getPrimaryKey(), fetchLatest);

		fetchLatest.resetOriginalValues();
	}

	/**
	 * Caches the fetch latests in the entity cache if it is enabled.
	 *
	 * @param fetchLatests the fetch latests
	 */
	@Override
	public void cacheResult(List<fetchLatest> fetchLatests) {
		for (fetchLatest fetchLatest : fetchLatests) {
			if (entityCache.getResult(
						fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
						fetchLatestImpl.class, fetchLatest.getPrimaryKey()) == null) {
				cacheResult(fetchLatest);
			}
			else {
				fetchLatest.resetOriginalValues();
			}
		}
	}

	/**
	 * Clears the cache for all fetch latests.
	 *
	 * <p>
	 * The {@link EntityCache} and {@link FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(fetchLatestImpl.class);

		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the fetch latest.
	 *
	 * <p>
	 * The {@link EntityCache} and {@link FinderCache} are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(fetchLatest fetchLatest) {
		entityCache.removeResult(fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
			fetchLatestImpl.class, fetchLatest.getPrimaryKey());

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@Override
	public void clearCache(List<fetchLatest> fetchLatests) {
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (fetchLatest fetchLatest : fetchLatests) {
			entityCache.removeResult(fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
				fetchLatestImpl.class, fetchLatest.getPrimaryKey());
		}
	}

	/**
	 * Creates a new fetch latest with the primary key. Does not add the fetch latest to the database.
	 *
	 * @param isLatest the primary key for the new fetch latest
	 * @return the new fetch latest
	 */
	@Override
	public fetchLatest create(boolean isLatest) {
		fetchLatest fetchLatest = new fetchLatestImpl();

		fetchLatest.setNew(true);
		fetchLatest.setPrimaryKey(isLatest);

		return fetchLatest;
	}

	/**
	 * Removes the fetch latest with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param isLatest the primary key of the fetch latest
	 * @return the fetch latest that was removed
	 * @throws NoSuchfetchLatestException if a fetch latest with the primary key could not be found
	 */
	@Override
	public fetchLatest remove(boolean isLatest)
		throws NoSuchfetchLatestException {
		return remove((Serializable)isLatest);
	}

	/**
	 * Removes the fetch latest with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the fetch latest
	 * @return the fetch latest that was removed
	 * @throws NoSuchfetchLatestException if a fetch latest with the primary key could not be found
	 */
	@Override
	public fetchLatest remove(Serializable primaryKey)
		throws NoSuchfetchLatestException {
		Session session = null;

		try {
			session = openSession();

			fetchLatest fetchLatest = (fetchLatest)session.get(fetchLatestImpl.class,
					primaryKey);

			if (fetchLatest == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchfetchLatestException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
					primaryKey);
			}

			return remove(fetchLatest);
		}
		catch (NoSuchfetchLatestException nsee) {
			throw nsee;
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected fetchLatest removeImpl(fetchLatest fetchLatest) {
		fetchLatest = toUnwrappedModel(fetchLatest);

		Session session = null;

		try {
			session = openSession();

			if (!session.contains(fetchLatest)) {
				fetchLatest = (fetchLatest)session.get(fetchLatestImpl.class,
						fetchLatest.getPrimaryKeyObj());
			}

			if (fetchLatest != null) {
				session.delete(fetchLatest);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		if (fetchLatest != null) {
			clearCache(fetchLatest);
		}

		return fetchLatest;
	}

	@Override
	public fetchLatest updateImpl(fetchLatest fetchLatest) {
		fetchLatest = toUnwrappedModel(fetchLatest);

		boolean isNew = fetchLatest.isNew();

		Session session = null;

		try {
			session = openSession();

			if (fetchLatest.isNew()) {
				session.save(fetchLatest);

				fetchLatest.setNew(false);
			}
			else {
				fetchLatest = (fetchLatest)session.merge(fetchLatest);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);

		if (isNew) {
			finderCache.removeResult(FINDER_PATH_COUNT_ALL, FINDER_ARGS_EMPTY);
			finderCache.removeResult(FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL,
				FINDER_ARGS_EMPTY);
		}

		entityCache.putResult(fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
			fetchLatestImpl.class, fetchLatest.getPrimaryKey(), fetchLatest,
			false);

		fetchLatest.resetOriginalValues();

		return fetchLatest;
	}

	protected fetchLatest toUnwrappedModel(fetchLatest fetchLatest) {
		if (fetchLatest instanceof fetchLatestImpl) {
			return fetchLatest;
		}

		fetchLatestImpl fetchLatestImpl = new fetchLatestImpl();

		fetchLatestImpl.setNew(fetchLatest.isNew());
		fetchLatestImpl.setPrimaryKey(fetchLatest.getPrimaryKey());

		fetchLatestImpl.setIsLatest(fetchLatest.isIsLatest());
		fetchLatestImpl.setRecordNumber(fetchLatest.getRecordNumber());

		return fetchLatestImpl;
	}

	/**
	 * Returns the fetch latest with the primary key or throws a {@link com.liferay.portal.kernel.exception.NoSuchModelException} if it could not be found.
	 *
	 * @param primaryKey the primary key of the fetch latest
	 * @return the fetch latest
	 * @throws NoSuchfetchLatestException if a fetch latest with the primary key could not be found
	 */
	@Override
	public fetchLatest findByPrimaryKey(Serializable primaryKey)
		throws NoSuchfetchLatestException {
		fetchLatest fetchLatest = fetchByPrimaryKey(primaryKey);

		if (fetchLatest == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchfetchLatestException(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY +
				primaryKey);
		}

		return fetchLatest;
	}

	/**
	 * Returns the fetch latest with the primary key or throws a {@link NoSuchfetchLatestException} if it could not be found.
	 *
	 * @param isLatest the primary key of the fetch latest
	 * @return the fetch latest
	 * @throws NoSuchfetchLatestException if a fetch latest with the primary key could not be found
	 */
	@Override
	public fetchLatest findByPrimaryKey(boolean isLatest)
		throws NoSuchfetchLatestException {
		return findByPrimaryKey((Serializable)isLatest);
	}

	/**
	 * Returns the fetch latest with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the fetch latest
	 * @return the fetch latest, or <code>null</code> if a fetch latest with the primary key could not be found
	 */
	@Override
	public fetchLatest fetchByPrimaryKey(Serializable primaryKey) {
		Serializable serializable = entityCache.getResult(fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
				fetchLatestImpl.class, primaryKey);

		if (serializable == nullModel) {
			return null;
		}

		fetchLatest fetchLatest = (fetchLatest)serializable;

		if (fetchLatest == null) {
			Session session = null;

			try {
				session = openSession();

				fetchLatest = (fetchLatest)session.get(fetchLatestImpl.class,
						primaryKey);

				if (fetchLatest != null) {
					cacheResult(fetchLatest);
				}
				else {
					entityCache.putResult(fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
						fetchLatestImpl.class, primaryKey, nullModel);
				}
			}
			catch (Exception e) {
				entityCache.removeResult(fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
					fetchLatestImpl.class, primaryKey);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return fetchLatest;
	}

	/**
	 * Returns the fetch latest with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param isLatest the primary key of the fetch latest
	 * @return the fetch latest, or <code>null</code> if a fetch latest with the primary key could not be found
	 */
	@Override
	public fetchLatest fetchByPrimaryKey(boolean isLatest) {
		return fetchByPrimaryKey((Serializable)isLatest);
	}

	@Override
	public Map<Serializable, fetchLatest> fetchByPrimaryKeys(
		Set<Serializable> primaryKeys) {
		if (primaryKeys.isEmpty()) {
			return Collections.emptyMap();
		}

		Map<Serializable, fetchLatest> map = new HashMap<Serializable, fetchLatest>();

		if (primaryKeys.size() == 1) {
			Iterator<Serializable> iterator = primaryKeys.iterator();

			Serializable primaryKey = iterator.next();

			fetchLatest fetchLatest = fetchByPrimaryKey(primaryKey);

			if (fetchLatest != null) {
				map.put(primaryKey, fetchLatest);
			}

			return map;
		}

		Set<Serializable> uncachedPrimaryKeys = null;

		for (Serializable primaryKey : primaryKeys) {
			Serializable serializable = entityCache.getResult(fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
					fetchLatestImpl.class, primaryKey);

			if (serializable != nullModel) {
				if (serializable == null) {
					if (uncachedPrimaryKeys == null) {
						uncachedPrimaryKeys = new HashSet<Serializable>();
					}

					uncachedPrimaryKeys.add(primaryKey);
				}
				else {
					map.put(primaryKey, (fetchLatest)serializable);
				}
			}
		}

		if (uncachedPrimaryKeys == null) {
			return map;
		}

		StringBundler query = new StringBundler((uncachedPrimaryKeys.size() * 2) +
				1);

		query.append(_SQL_SELECT_FETCHLATEST_WHERE_PKS_IN);

		for (Serializable primaryKey : uncachedPrimaryKeys) {
			query.append((boolean)primaryKey);

			query.append(StringPool.COMMA);
		}

		query.setIndex(query.index() - 1);

		query.append(StringPool.CLOSE_PARENTHESIS);

		String sql = query.toString();

		Session session = null;

		try {
			session = openSession();

			Query q = session.createQuery(sql);

			for (fetchLatest fetchLatest : (List<fetchLatest>)q.list()) {
				map.put(fetchLatest.getPrimaryKeyObj(), fetchLatest);

				cacheResult(fetchLatest);

				uncachedPrimaryKeys.remove(fetchLatest.getPrimaryKeyObj());
			}

			for (Serializable primaryKey : uncachedPrimaryKeys) {
				entityCache.putResult(fetchLatestModelImpl.ENTITY_CACHE_ENABLED,
					fetchLatestImpl.class, primaryKey, nullModel);
			}
		}
		catch (Exception e) {
			throw processException(e);
		}
		finally {
			closeSession(session);
		}

		return map;
	}

	/**
	 * Returns all the fetch latests.
	 *
	 * @return the fetch latests
	 */
	@Override
	public List<fetchLatest> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the fetch latests.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link fetchLatestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of fetch latests
	 * @param end the upper bound of the range of fetch latests (not inclusive)
	 * @return the range of fetch latests
	 */
	@Override
	public List<fetchLatest> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the fetch latests.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link fetchLatestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of fetch latests
	 * @param end the upper bound of the range of fetch latests (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of fetch latests
	 */
	@Override
	public List<fetchLatest> findAll(int start, int end,
		OrderByComparator<fetchLatest> orderByComparator) {
		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the fetch latests.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link fetchLatestModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	 * </p>
	 *
	 * @param start the lower bound of the range of fetch latests
	 * @param end the upper bound of the range of fetch latests (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param retrieveFromCache whether to retrieve from the finder cache
	 * @return the ordered range of fetch latests
	 */
	@Override
	public List<fetchLatest> findAll(int start, int end,
		OrderByComparator<fetchLatest> orderByComparator,
		boolean retrieveFromCache) {
		boolean pagination = true;
		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
				(orderByComparator == null)) {
			pagination = false;
			finderPath = FINDER_PATH_WITHOUT_PAGINATION_FIND_ALL;
			finderArgs = FINDER_ARGS_EMPTY;
		}
		else {
			finderPath = FINDER_PATH_WITH_PAGINATION_FIND_ALL;
			finderArgs = new Object[] { start, end, orderByComparator };
		}

		List<fetchLatest> list = null;

		if (retrieveFromCache) {
			list = (List<fetchLatest>)finderCache.getResult(finderPath,
					finderArgs, this);
		}

		if (list == null) {
			StringBundler query = null;
			String sql = null;

			if (orderByComparator != null) {
				query = new StringBundler(2 +
						(orderByComparator.getOrderByFields().length * 2));

				query.append(_SQL_SELECT_FETCHLATEST);

				appendOrderByComparator(query, _ORDER_BY_ENTITY_ALIAS,
					orderByComparator);

				sql = query.toString();
			}
			else {
				sql = _SQL_SELECT_FETCHLATEST;

				if (pagination) {
					sql = sql.concat(fetchLatestModelImpl.ORDER_BY_JPQL);
				}
			}

			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(sql);

				if (!pagination) {
					list = (List<fetchLatest>)QueryUtil.list(q, getDialect(),
							start, end, false);

					Collections.sort(list);

					list = Collections.unmodifiableList(list);
				}
				else {
					list = (List<fetchLatest>)QueryUtil.list(q, getDialect(),
							start, end);
				}

				cacheResult(list);

				finderCache.putResult(finderPath, finderArgs, list);
			}
			catch (Exception e) {
				finderCache.removeResult(finderPath, finderArgs);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the fetch latests from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (fetchLatest fetchLatest : findAll()) {
			remove(fetchLatest);
		}
	}

	/**
	 * Returns the number of fetch latests.
	 *
	 * @return the number of fetch latests
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(FINDER_PATH_COUNT_ALL,
				FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query q = session.createQuery(_SQL_COUNT_FETCHLATEST);

				count = (Long)q.uniqueResult();

				finderCache.putResult(FINDER_PATH_COUNT_ALL, FINDER_ARGS_EMPTY,
					count);
			}
			catch (Exception e) {
				finderCache.removeResult(FINDER_PATH_COUNT_ALL,
					FINDER_ARGS_EMPTY);

				throw processException(e);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return fetchLatestModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the fetch latest persistence.
	 */
	public void afterPropertiesSet() {
	}

	public void destroy() {
		entityCache.removeCache(fetchLatestImpl.class.getName());
		finderCache.removeCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.removeCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	@ServiceReference(type = EntityCache.class)
	protected EntityCache entityCache;
	@ServiceReference(type = FinderCache.class)
	protected FinderCache finderCache;
	private static final String _SQL_SELECT_FETCHLATEST = "SELECT fetchLatest FROM fetchLatest fetchLatest";
	private static final String _SQL_SELECT_FETCHLATEST_WHERE_PKS_IN = "SELECT fetchLatest FROM fetchLatest fetchLatest WHERE isLatest IN (";
	private static final String _SQL_COUNT_FETCHLATEST = "SELECT COUNT(fetchLatest) FROM fetchLatest fetchLatest";
	private static final String _ORDER_BY_ENTITY_ALIAS = "fetchLatest.";
	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY = "No fetchLatest exists with the primary key ";
	private static final Log _log = LogFactoryUtil.getLog(fetchLatestPersistenceImpl.class);
}