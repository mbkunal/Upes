create table KMB_Job_Application_Records (
	RecordNumber LONG not null primary key,
	SapId LONG,
	JobId LONG,
	ApplicationDate DATE null
);

create table KMB_fetchLatest (
	isLatest BOOLEAN not null primary key,
	recordNumber LONG
);